# Taxi
Taxi Management System

JavaFX Desktop Application with variaties of libraries (JFoenix, FontAwesome, etc)


## DashBoard View

![alt text](./screen-shots/Dash_board.png)

## Chart Animation (scrolling)

![alt text](./screen-shots/charts_animation.png)

## Driver Account 

![alt text](./screen-shots/Driver_edit.png)

## Driver Sign-up

![alt text](./screen-shots/Driver_sign_up.png)

## User 

![alt text](./screen-shots/User_sign_up.png)

## Login Form

![alt text](./screen-shots/login_form.PNG)
